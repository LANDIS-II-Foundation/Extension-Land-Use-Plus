# notes
# Rscript.exe
# lu+ use full path name of this file
# scenario txt disturbance extension order matters- wind must be before LU+
# do all extension timesteps jive?
print("connected to R")
#
whichComputer <- "dml486"
scenarioName <- "LandUsePlusExampleFile"
path <- paste0("C:/Users/",whichComputer,"/Documents/LANDIS/",scenarioName)
print(path)
library(tidyverse)
library(terra)
setwd(path)
getwd()
#
timestep <- readLines("lockfile",n = 1)  
print(timestep)
#
inputWindOutput <- paste0(path,"/output/wind/severity-",timestep,".img")
windRas <- rast(inputWindOutput)
print("wind ras freq "); print(freq(windRas)) 
# inputLU <- paste0(path,"/n25luPause/land-use-",timestep,".img")
# inputLUras <- raster(inputLU)

maskRas<-rast(paste0(path,"/eco.img"))
ext(windRas)<-ext(maskRas)
luNew <- windRas
luNew[luNew >= 4] <- 4
luNew[luNew < 4] <- 2
luNew[is.null(luNew)] <- 0
luNew[is.na(luNew)] <- 0
luNew[is.nan(luNew)] <- 0
luNew[is.infinite(luNew)] <- 0
print(freq(luNew))
writeRaster(luNew,paste0(path,"/n25luPause/land-use-",timestep,".img") ,overwrite=TRUE,datatype="INT2S") #,".img"
#
print("scriptcomplete")