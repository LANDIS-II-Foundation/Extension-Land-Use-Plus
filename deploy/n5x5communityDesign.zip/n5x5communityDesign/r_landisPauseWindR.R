# notes
# Rscript.exe
# lu+ use full path name of this file
# scenario txt disturbance extension order matters- wind must be before LU+
# do all extension timesteps jive?
print("i am a simple script")
#
whichComputer <- "danel"
path <- paste0("C:/Users/",whichComputer,"/Desktop/n5x5communityDesign")

library(tidyverse)
library(raster)
setwd(path)
getwd()
#
timestep <- readLines("lockfile",n = 1)  
print(timestep)
#
inputWindOutput <- paste0(path,"/output/wind/severity-",timestep,".img")
windRas <- raster(inputWindOutput)
print(freq(windRas))
# inputLU <- paste0(path,"/n25luPause/land-use-",timestep,".img")
# inputLUras <- raster(inputLU)

maskRas<-raster(paste0(path,"/eco.img"))
extent(windRas)<-extent(maskRas)
luNew <- windRas
luNew[luNew >= 4] <- 4
luNew[luNew < 4] <- 2
luNew[is.null(luNew)] <- 0
luNew[is.na(luNew)] <- 0
luNew[is.nan(luNew)] <- 0
luNew[is.infinite(luNew)] <- 0
print(freq(luNew))
writeRaster(luNew,paste0(path,"/n25luPause/land-use-",timestep,".img") ,overwrite=TRUE,format="HFA",datatype="INT2S") #,".img"
#
print("scriptcomplete")