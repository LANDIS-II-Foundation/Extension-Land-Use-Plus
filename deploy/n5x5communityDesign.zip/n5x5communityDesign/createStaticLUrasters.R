library(tidyverse)
library(raster)
#
path <- "C:/Users/danel/Desktop/testLandscapes/n5x5treatment"

# create LU raster that prohibits harvest in row2 for the duration of the simulation
setwd(path)
getwd()
#
path <- "C:/Users/danel/Desktop/testLandscapes/n5x5communityDesign"
setwd(path)
getwd()
ecoras <- raster(paste0(path,"/eco.img"))
communityPlanRas <- ecoras
newVals <- c(2,2,3,4,4,2,2,3,4,4,2,5,3,4,4,6,1,3,3,3,6,2,2,2,2)
values(communityPlanRas) <- newVals
timesteps <- seq(25,105,by=5)
for(i in seq_along(timesteps)){
writeRaster(communityPlanRas,paste0(path,"/n25lu/land-use-",timesteps[i],".tif") ,overwrite=TRUE,format="GTiff",datatype="INT2S") #,".img"
}
#
ecoras[ecoras==1] <- 2
timesteps <- seq(0,20,by=5)
for(i in seq_along(timesteps)){
  writeRaster(ecoras,paste0(path,"/n25lu/land-use-",timesteps[i],".tif") ,overwrite=TRUE,format="GTiff",datatype="INT2S") #,".img"
}


##
mgmt5x5 <- raster(paste0(path,"/mgmt_n5x5forTreatment.img"))
luNew <- mgmt5x5
luNew[luNew == 2] <- 3
luNew[luNew == 1] <- 2
luNew[luNew > 2] <- 4
luNew[is.null[luNew]] <- 0
luNew[is.na(luNew)] <- 0
luNew[is.nan(luNew)] <- 0
luNew[is.infinite(luNew)] <- 0
timesteps <- 1:105
for(i in seq_along(timesteps)){
  writeRaster(luNew,paste0(path,"/n25luPreventHarvest/land-use-",timesteps[i],".img") ,overwrite=TRUE,format="HFA",datatype="INT2S") #,".img"
}




# look at rasters
wd <- "C:/Users/danel/Desktop/testLandscapes/n5x5treatment"
pattern <- "land-use.*.img$"
lucpath <- paste0(wd,"/n25luPause")
i<-list.files(path=paste0(lucpath),pattern=pattern)
setwd(lucpath)
st<-stack(i)
freq(st,merge=TRUE)
#

#
wd <- "C:/Users/danel/Desktop/testLandscapes/n5x5treatment"
pattern <- "severity.*.img$"
windpath <- paste0(wd,"/output/wind")
ii<-list.files(path=paste0(windpath),pattern=pattern)
setwd(windpath)
st2<-stack(ii)
freq(st2,merge=TRUE)

#
