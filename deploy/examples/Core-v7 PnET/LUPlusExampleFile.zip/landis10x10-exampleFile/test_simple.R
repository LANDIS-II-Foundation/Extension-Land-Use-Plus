# simple example script that reads previous timestep raster, "does something," and writes current timestep raster.

print("example script")
wd <- "C:/Users/dml486/Desktop/landis10x10-exampleFile" #set working directory
library('raster')
timestep <-as.integer( readLines("lockfile",n = 1) )-10 # we are using lockfile to keep track of simulation year
print(timestep)
print("above should be previous timestep") # unnecessary but added for error checking
input <- paste0(wd,"/LUI_maps/land-use-",timestep,".img")
inputR <- raster(input)
outR <- inputR + 1
print(values(outR))
# to avoid errors we run this
outR[is.na(outR)] <- 0
outR[is.nan(outR)] <- 0
outR[is.null(outR)] <- 0
outR[is.infinite(outR)] <- 0
print("below should be current timestep") # unnecessary but added for error checking
timestep <-as.integer( readLines("lockfile",n = 1) )
print(timestep)
writeRaster(outR,filename= paste0(wd,"/LUI_maps/land-use-",timestep,".img"),overwrite = T,format="HFA", datatype="INT2S")
print("scriptcomplete") # unnecessary but useful for error checking