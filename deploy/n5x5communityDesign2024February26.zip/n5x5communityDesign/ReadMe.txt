
# download extensions from 
https://github.com/LANDIS-II-Foundation/Extension-PnET-Succession/tree/master/deploy/v5.1_installers

in scenario file rename Land Use v3.3 to match extension file