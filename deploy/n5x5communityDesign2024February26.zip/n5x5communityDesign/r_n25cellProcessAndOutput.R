#####################################################################################################################################
# Setup
#####################################################################################################################################
library(tidyverse)
library(raster)
options(scipen=999)

iccols <- c("ACSA"= "#276419",
            "BELE"= "#35978f", 
            "CAGL"= "#543005", 
            "PIST"= "#33FF33",
            "PRSE"= "#de77ae", 
            "QURU"= "#f1b6da", 
            "TSCA"= "#0000FF"
            #"BEPO"="#542788"
            )

#
# Setup assumes folder in on Desktop and that you have not changed the folder name
# Reading in rasters assumes the rasters are all in one folder
#####################################################################################################################################
# CHANGE
#####################################################################################################################################
whichComputer <- "dml486" # "PUT YOUR USER NAME HERE
#
icName <- "eco" # ic RASTER do not add .img  
#
# name on output folder
outputid <- "stress" # "static" # "dynamic" #"windSal" 
runNumber <- "022603" # mo day run number
#
startYear <- 2000 
simuLength <- 80
outputpnettimestep <- 5
sevWindVal <- 3
#
#####################################################################################################################################
# set names based on above inputs
#####################################################################################################################################
path <-  paste0("C:/Users/",whichComputer,"/Desktop/n5x5communityDesign") 
#
simuName <- paste0(outputid,"_r",runNumber)
#
simu <- paste0("output_",simuName) 
#
simuPath <- paste0(path,"/",simu) # landis outputs
#
pnetOutputYears <- seq(startYear+outputpnettimestep,startYear+simuLength,by=outputpnettimestep)
#crosswalk for matching site various outputs
lookuptable <- data.frame(
  timestep=seq(0,simuLength,by=1),
  year=seq(startYear,startYear+simuLength,by=1),
  pnetOutputYear=c(0,rep(pnetOutputYears,each=5) ) )

########################################################################################################################################
#Move files and rename output folder
#Do not rerun - RUN ONLY once per simulation
########################################################################################################################################

ll<-readLines(paste0(path,"/Landis-log.txt"))
writeLines(ll,paste0(path,"/output","/Landis-log.txt"))
pnet<-readLines(paste0(path,"/PnET_succession_Land.txt"))
writeLines(pnet,paste0(path,"/output/PnET_succession_Land.txt"))
#
os<-readLines(paste0(path,"/PNEToutputsites.txt"))
writeLines(os,paste0(path,"/output/PNEToutputsites.txt"))
#
scen<-readLines(paste0(path,"/scenario.txt"))
writeLines(scen,paste0(path,"/output/scenario.txt"))
#
windlog <- paste0(path,"/wind-events-log.csv")
file.copy(windlog,paste0(path,"/output/wind-events-log.csv") )   
#
# put pnetoutputs in folder
setwd(paste0(path,"/output"))
dir.create("PNEToutputsites")
pnetsiteslf <- list.files(paste0(path,"/output"),pattern="Site.*.")
file.rename(paste0(path,"/output/",pnetsiteslf),paste0(path,"/output/PNEToutputsites/",pnetsiteslf))
#
#change name of output file to make unique
setwd(path)
file.rename(paste0(path,"/output"),paste0(path,"/",simu))
#

########################################################################################################################################
#create dataframe with cellnumber and icVal
########################################################################################################################################
# create a dataframe of cell numbers and initial communities
icras <- raster(paste0(path,"/",icName,".img"))
mapcode <- getValues(icras)
cell <- 1:length(mapcode)
mcSite <-  as.data.frame(cbind(mapcode, cell ))
#
########################################################################################################################################
#Process pnet raster outputs 
########################################################################################################################################
# list AGB raster names
wd <- setwd(file.path(simuPath,"agbiomass"))
lf <- list.files(path=file.path(simuPath,"agbiomass"), pattern=paste0("*.img$"), recursive=FALSE)  
# stack rasters
st<-stack(lf)
names(st) <- substr(lf,1,nchar(lf)-4)
# get values and and set up as dataframe
val <- as.data.frame(getValues(st))
val$cell <- row.names(val)
cellBioOverTime <- gather(val,key=timeLong,value=agbgm2,-cell) %>% 
  filter(!str_detect(timeLong,"AllSpecies")) %>% #use for pnetv5
  mutate(cell=as.integer(cell)) %>% 
  left_join(mcSite)
head(cellBioOverTime)
#
# for these substrings to work timeLong must be the expected length
cellBioOverTime$time <- as.integer(substr(cellBioOverTime$timeLong, 20, nchar(cellBioOverTime$timeLong)))
cellBioOverTime$genuspec <- substr(cellBioOverTime$timeLong,11,18)  
cellBioOverTime$gesp <- toupper(paste0(substr(cellBioOverTime$genuspec,1,2),substr(cellBioOverTime$genuspec,5,6))) 
#
# summarize raster data and add simulation ID
landisOut <- cellBioOverTime %>% 
  group_by(cell,mapcode,time) %>% 
  mutate(cellAGBgm2=sum(agbgm2),
         year=time+startYear,
         simuName=simuName) %>% 
  rename(spAGBgm2=agbgm2,AGBgm2=cellAGBgm2) %>% 
  ungroup() %>% 
  dplyr::select(simuName,cell,timestep=time,mapcode,year,gesp,spAGBgm2,AGBgm2) 
#
########################################################################################################################################
#Process land use and wind outputs 
########################################################################################################################################
# LAND USE row column crosswalk
#prep to convert site log row-col to cell values
siteRas <- raster(paste0(path,"/ic1_25.img"))
# make a data frame with cell values in their proper row/column placement in the raster
siteRasMat <- as.data.frame(as.matrix(siteRas))
# set the column names as column_number
names(siteRasMat) <- seq(1:ncol(siteRasMat))
# add a column that is the row number
siteRasMat$row <- seq(1: nrow(siteRasMat))
# put the data frame into long format (if so desired)
cellRasMatLong <- gather(siteRasMat, key=column, value=cellVal, -row, factor_key=TRUE) %>% 
  mutate(column=as.integer(column))

# LAND USE
# Process site log 
siteLog <- read.csv(paste0(simuPath,"/land-use/site-log.csv"))
#
# LU+ total bio gm2 removed per cell per timestep
siteLogSummary <- siteLog %>% 
    mutate(cellBioRem=rowSums(dplyr::select(.,abiebals:ulmuamer))) %>% 
    pivot_longer(cols=abiebals:ulmuamer,names_to="genuspec",values_to="spBioRem") %>% 
    mutate(gesp=toupper(paste0(substr(genuspec,1,2),substr(genuspec,5,6))) )
  
# bring in land use crosswalk and join to site log
siteLogOut <- siteLogSummary %>% 
    left_join(cellRasMatLong) %>%
    mutate(simuName=simuName,
           year=as.integer(timestep)+startYear) %>% 
    rename(cell=cellVal) %>% 
    left_join(lookuptable) %>%  #lookuptable allows you to sum to pnetoutput years
    group_by(pnetOutputYear,cell,genuspec,gesp,simuName) %>% 
    summarise(cellBioRem=sum(cellBioRem,na.rm=TRUE),spBioRem=sum(spBioRem)) %>% 
    rename(year=pnetOutputYear)
#
# total cell AGB removed using LU+
  tslo <- siteLogOut %>% 
    group_by(year,cell,cellBioRem) %>% 
    mutate(year=as.factor(year)) %>% 
    summarise(tagbgm2Rem=sum(spBioRem))
  tslo %>% filter(year==2040&cellBioRem>0)
#
# WIND
# Bring in wind severity rasters and stack - as long as extension is active
pattern <- "severity.*.img$"
windpath <- paste0(simuPath,"/wind")
ii<-list.files(path=paste0(windpath),pattern=pattern)
setwd(windpath); st2<-stack(ii)
names(st2) <- substr(ii,1,nchar(ii)-4)
#
# bind wind severity with mcSite (cell numbers)
windVal <- getValues(st2)
mcSiteWind <- as.data.frame(cbind(mcSite,windVal))
# all wind 
windLong <- mcSiteWind %>% 
  gather(key=timeLong,value=severity,-c(mapcode:cell)) %>% 
  separate(timeLong,c(NA,"timestep")) %>% 
  mutate(timestep=as.integer(timestep),
         year=startYear+timestep,
         actSeverity=severity-1)
#
# use for joining
windOut <- windLong %>% 
  filter(actSeverity>0) %>% 
  left_join(lookuptable) %>% 
  group_by(cell,pnetOutputYear) %>% 
  summarise(maxActSeverity=max(actSeverity)) %>%   # output max severity within the 5 year pnet timestep - for joining
  rename(year=pnetOutputYear)
#
sevWind <- windLong %>% filter(actSeverity >= sevWindVal) 
#
########################################################################################################################################
# Create figures
########################################################################################################################################
# AGB stacked and separate vertical red lines indicate years with wind damage
#
stackedAGB <- landisOut %>% 
  filter(spAGBgm2>0) %>% 
  ggplot(aes(x=year,y=spAGBgm2,fill=gesp)) +
  geom_area(lwd=1) +
  theme_bw()+
  theme(axis.text.x=element_text(angle=90,vjust=-0.1))+
  scale_fill_manual(values=iccols)+
  facet_wrap(~cell) +
  ggtitle(paste0(simuName,"AGB gm2"))
#
landisOut %>% group_by(year,cell) %>% summarise(tbio=sum(spAGBgm2)) %>% 
  filter(cell %in% c(1,4)) %>% filter(year<2010)
#
sppagb <- landisOut %>% 
  filter(spAGBgm2>0) %>% 
  ggplot(aes(x=year,y=spAGBgm2,color=gesp)) +
  geom_line(lwd=1) +
  theme_bw()+
  theme(axis.text.x=element_text(angle=90,vjust=-0.1))+
  scale_color_manual(values=iccols)+
  facet_wrap(~cell) +
  ggtitle(paste0(simuName,"AGB gm2"))
#
stackedAGB
sppagb
#
# disturbance and wind
slosub <- siteLogOut %>% 
  filter(cellBioRem>0) 
#
dist <- siteLogOut %>%
  ungroup() %>% 
  dplyr::select(year,cell,simuName,cellBioRem) %>%
  distinct() %>% 
  filter(cellBioRem>0) %>% 
  ggplot(aes(x=year,y=cellBioRem)) +
  #geom_point(size=.5) +
  geom_point(data=slosub,aes(x=year,y=cellBioRem),size=1,color="red") +
  geom_vline(data=sevWind,aes(xintercept=year),lwd=.4,alpha=.5,color="blue" ) + #"blue"
  #geom_text(data=windOut,aes(x=year,y=0,label=maxActSeverity),col="blue",vjust=-.1,size=2) +
  theme_bw()+
  theme(axis.text.x=element_text(angle=90,vjust=-0.1,size=8)) +
  facet_wrap(~cell) +
  ggtitle(paste0(simuName,"Removed AGB gm2"))
dist
#

########################################################################################################################################
# Save outputs
########################################################################################################################################
#
ggsave(filename=paste0(simuName,"stackedAreaAGBgm2.png"),plot=stackedAGB,device="png",path=paste0(path,"/OUTPUTS/outputFigures"),width=9,height=8,units=c("in"))
ggsave(filename=paste0(simuName,"sppAGBgm2.png"),plot=sppagb,device="png",path=paste0(path,"/OUTPUTS/outputFigures"),width=9,height=8,units=c("in"))
#ggsave(filename=paste0(simuName,"annGrowthCMgha.png"),plot= annGrowth,device="png",path=paste0(path,"/OUTPUTS/outputFigures"),width=9,height=8,units=c("in"))
ggsave(filename=paste0(simuName,"siteLogRemagbgm2.png"),plot= dist,device="png",path=paste0(path,"/OUTPUTS/outputFigures"),width=9,height=8,units=c("in"))
#
write.csv(landisOut,paste0(path,"/OUTPUTS/outputCSVs/n5x5CellBiomass_",simuName,".csv"),row.names=FALSE )
write.csv(siteLogOut,paste0(path,"/outputs/outputCSVs/siteLogREM_",simuName,".csv"),row.names=FALSE)
#






##############################################################################################
# STOP                STOP                              STOP                STOP
##############################################################################################
# annual growth
#
# Annual growth CMgha, outliers are not shown
growthdf <- cellBioOverTime %>% 
  group_by(cell,mapcode,time) %>% 
  dplyr::summarise(cellAGBgm2=sum(agbgm2)) %>% #
  ungroup() %>% 
  mutate(year=as.factor(time+startYear)) %>% 
  rename(SHORT=mapcode) %>% 
  group_by(cell,SHORT) %>% 
  arrange(cell,time) %>% 
  mutate(annGrowthAGBgm2=(cellAGBgm2-lag(cellAGBgm2))/outputpnettimestep, 
         annGrowthCMgha=round(annGrowthAGBgm2/2/100,2)) 
#
# annual growth
annGrowth <- ggplot(growthdf,aes(x=as.factor(year),y=annGrowthCMgha)) +
  geom_hline(yintercept = 0,alpha=0.5) +
  geom_boxplot(outlier.shape=NA)  +
  theme_bw() +
  scale_y_continuous(limits=c(NA,NA),breaks=seq(-2,2,by=.5)) +
  coord_cartesian(ylim=c(-2,2)) +
  theme(axis.text.x=element_text(angle=90,vjust=-0.1),
        legend.position="bottom")  +
  ggtitle(paste0(simuName,"Annual growth Mgha"))
annGrowth
#



# pnetoutputsites files
fiveYearVec <- seq(startYear,startYear+simuLength,by=5)
# cohort information
#
lfc <- list.files(path=file.path(path,simu,"PNEToutputsites"), pattern="Cohort_.*.csv", recursive=TRUE,full.names=TRUE)
results <- sapply(lfc,function(x) read.csv(x),simplify=FALSE)
cohorts <- as.data.frame(do.call(rbind, results), stringsAsFactors = FALSE)
#
cohorts$fullname <- row.names(cohorts)
cohorts$fullname[1]
#
fullcohorts <- cohorts %>% 
  separate(fullname, c(NA,"partname"),sep="output_" ) %>% 
  separate(partname,c("version","run",NA ,"site",NA,"genuspec","yearEst",NA,NA)) %>% 
  separate(site,c(NA, "cell"),sep ="Site",remove=FALSE) %>%
  mutate(cell=as.numeric(cell)) %>% 
  left_join(mcSite) %>% 
  rowid_to_column(var="rowid") %>% 
  column_to_rownames("rowid") %>% 
  separate(Time,c("yr","mo")) %>% 
  mutate(year=as.integer(yr),
         month=as.integer(mo)) %>% 
  dplyr::select(run,
                site,
                cell,
                mapcode,
                year,
                mo,
                month,
                yearEst,
                genuspec,
                age=Age.yr.,
                topLayer=TopLayer...,
                LAIm2=LAI.m2.,
                leafon=LeafOn...,
                FActiveBio=FActiveBiom.gDW_gDW.,
                limitingFactor=Limiting.Factor,
                "folgDW"=Fol.gDW., 
                "rootgDW"=Root.gDW., 
                "woodgDW"=Wood.gDW., 
                "siteLAI"=LAI.m2.,
                "age"=Age.yr.,
                "NSCgC"=NSC.gC.,
                "NSCfrac"=NSCfrac...,
                "fage"=fage...,
                "maintResp"=MaintenanceRespiration.gC_mo.,
                "folResp"=FolResp.gC_m2_mo.,
                "NetPsn"=NetPsn.gC_m2_mo.)  %>% 
  mutate(gesp=toupper(paste0(substr(genuspec,1,2),substr(genuspec,5,6))),
         gesp=as.factor(gesp))
#
fullcohorts$genuspec[1]
View(fullcohorts %>% 
       filter(year>=2000) %>% 
  filter(year<=2015&month==42) %>% 
  dplyr::select(cell,year,genuspec,yearEst,woodgDW) %>% 
    group_by(cell,year,genuspec) %>% 
    summarise(twood=sum(woodgDW,na.rm=TRUE)) %>% 
  filter(cell%in%c(1,5)) %>% 
    pivot_wider(id_cols=c(cell,genuspec),names_from=year,values_from=twood) %>% 
    arrange(genuspec,cell) 
)
#
# pnetOutputsites Site file
#
monthcw <- data.frame(mo=c("00","08","17","25","33","42","50","58","67","75","83","92"),
                      month=c(0,8,17,25,33,42,50,58,67,75,83,92),
                      month1_12=1:12)
lfs <- list.files(path=file.path(path,simu,"PNEToutputsites"), pattern="Site.csv", recursive=TRUE,full.names=TRUE)
sresults <- sapply(lfs,function(x) read.csv(x),simplify=FALSE)
sitesOut <- as.data.frame(do.call(rbind, sresults), stringsAsFactors = FALSE)
#

sitesOut$fullname <- row.names(sitesOut)
sitesOut$fullname[1]
#
so1 <- sitesOut %>% 
  separate(fullname,c(NA,"siteLong"),sep="/output_") %>% 
  separate(siteLong,c("version","run",NA,"site")) %>% 
  dplyr::select(
    Time,
    Ecoregion,
    SoilType,
    NrOfCohorts,
    layers=Layers,
    lai=LAI.m2.,
    run,
    site,
    woodgdw=Wood.gDW.,
    woodsenescencegdw=WoodSenescence.gDW_m2.,
    cwdgdw=CWD.gDW_m2.,
    Precip.mm.mo.,
    Water.m.m.,
    NetPsn.gC_m2_mo.,
    PAR0,
    SubCanopyPAR) %>% 
  mutate(Time=round(Time,2)) %>% 
  separate(Time,c("yr","mo")) %>% 
  mutate( mo=ifelse(is.na(mo),0,mo))
#
#where does the wood go after severe wind? (cwd)
print((so1 %>% dplyr::select(site,yr,mo,woodgdw,cwdgdw) %>% filter(site=="Site1"&yr>2025&yr<2040)),row.names=FALSE)


### this deletes contents of OUTPUTS folder USE WITH CAUTION
# unlink(paste0(path,"/OUTPUTS/outputCSVs"), recursive = TRUE)
# unlink(paste0(path,"/OUTPUTS/outputFigures"), recursive = TRUE)
# dir.create(paste0(path,"/OUTPUTS/outputCSVs"))
# dir.create(paste0(path,"/OUTPUTS/outputFigures"))
# 
