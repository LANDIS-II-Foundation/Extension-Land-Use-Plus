library(tidyverse)
library(raster)

whichComputer <- "danel"
wd <- paste0("C:/Users/",whichComputer,"/Desktop/n5x5communityDesign")
#
pattern <- "land-use.*.img$"
lfr <-list.files(path=paste0(wd,"/n25lu"), pattern=pattern)
lfr
setwd(lucpath); st <- stack(lfr)
#
#ordered freq table
a <- as.data.frame(freq(st,merge=TRUE)) %>% 
  gather(key=luras,value=npix,-value) %>% 
  separate(luras,c("landUse",NA,"time")) %>%
  mutate(time=as.integer(time)) %>% 
  arrange(time) %>% 
  pivot_wider(id_cols=value,names_from=time,values_from=npix)
a
############################################################################
# 1 conserved forest
# 2 working woodlands
# 3 initial forest management
# 4 permaculture
# 5 ag
# 6 residential maintenance - prevent estab
# 7 residential initial - remove trees
#22 working woodlands uneven harvest
############################################################################
#
# loop through for multiple timesteps
#
# change time 0-4 to singleValue noChange
x <- raster(paste0(lucpath,"/",lfr[[1]]) ) 
values(x) <- 1
#
x[is.null(x)] <- 0
x[is.na(x)] <- 0
x[is.nan(x)] <- 0
x[is.infinite(x)] <- 0
#
timestep <- 0:4
for(i in seq_along(timestep)){
  writeRaster(x,paste0(wd,"/n25lu/land-use-",timestep[i],".img") ,overwrite=TRUE,format="HFA",datatype="INT2S") #,".img"
}
# time 5-19 - forest managment only
x5 <- raster(paste0(lucpath,"/",lfr[[1]]) ) 
values(x5) <- c(3,3,3,1,1,
                3,3,3,1,1,
                3,3,3,1,1,
                3,3,3,3,3,
                3,3,3,3,3)
x5[is.null(x5)] <- 0
x5[is.na(x5)] <- 0
x5[is.nan(x5)] <- 0
x5[is.infinite(x5)] <- 0
timestep <- 5:19# 5:19
for(i in seq_along(timestep)){
  writeRaster(x5,paste0(wd,"/n25lu/land-use-",timestep[i],".img") ,overwrite=TRUE,format="HFA",datatype="INT2S") #,".img"
  
}
#
#initial res tree removal time 20
x <- raster(paste0(lucpath,"/",lfr[[1]]) )
values(x) <-  c(2,2,3,1,1,
                2,2,3,1,1,
                2,4,3,1,1,
                7,5,3,3,3,
                7,2,2,2,2)
x[is.null(x)] <- 0
x[is.na(x)] <- 0
x[is.nan(x)] <- 0
x[is.infinite(x)] <- 0
writeRaster(x,paste0(lucpath,"/land-use-20.img") ,overwrite=TRUE,format="HFA",datatype="INT2S") 


# res prevent est
x20 <- raster(paste0(lucpath,"/",lfr[[1]]) ) 
values(x20) <- c(2,2,3,1,1,
                 2,2,3,1,1,
                 2,4,3,1,1,
                 6,5,3,3,3,
                 6,2,2,2,2)
x20[is.null(x20)] <- 0
x20[is.na(x20)] <- 0
x20[is.nan(x20)] <- 0
x20[is.infinite(x20)] <- 0
timestep <- 21:105
for(i in seq_along(timestep)){
  writeRaster(x20,paste0(wd,"/n25lu/land-use-",timestep[i],".img") ,overwrite=TRUE,format="HFA",datatype="INT2S") #,".img"
  
}

#
values(x) <- c(rep(4,each=5),rep(1,each=5)) 

x[is.null(x)] <- 0
x[is.na(x)] <- 0
x[is.nan(x)] <- 0
x[is.infinite(x)] <- 0
timestep <- 6:19# 5:19
for(i in seq_along(timestep)){
  writeRaster(x,paste0(wd,"/n25lu/land-use-",timestep[i],".tif") ,overwrite=TRUE,format="GTiff",datatype="INT2S") #,".img"
  
}
#

#  change 1 raster at time 40 to simulate another harvest
x1 <- raster(paste0(wd,"/n25lu/land-use-40.img"))
values(x1) <- c(22,22,3,1,1,
                22,22,3,1,1,
                22,4,3,1,1,
                6,5,3,3,3,
                6,22,22,22,22)
x1[is.null(x1)] <- 0
x1[is.na(x1)] <- 0
x1[is.nan(x1)] <- 0
x1[is.infinite(x1)] <- 0
writeRaster(x1,paste0(lucpath,"/land-use-40.img") ,overwrite=TRUE,format="HFA",datatype="INT2S")   
#

#